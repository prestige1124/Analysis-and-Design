//============================================================================
// Name        : ABCU Advising.cpp
// Author      : Jake Brewer 
// Version     : 1.0
// Copyright   : 6/24/23 
// Description : CS300 Project 2 (ABCU Course Planner)
//============================================================================

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstring>
using namespace std;


// assign strign variable and spliut string
// assign token for int
struct Course {

    string courseNum;
    string name;
    vector < string > prereq;
};
vector < string > tokenize(string s, string del = " ") { 
    vector < string > A;

    int beginning = 0;
    int end = s.find(del);
    while (end != -1) {

        A.push_back(s.substr(beginning, end - beginning));
        beginning = end + del.size();
        end = s.find(del, beginning);
    }
    A.push_back(s.substr(beginning, end - beginning));

    return A;
}

// load .txt file from file explorer
// create loop though data on file
// close file at end of loop
vector < Course > LoadDataStructure() {  
    ifstream file;
    cout << "Please enter file path: ABCU_Advising_Program_Input.txt ";
    file.open("ABCU_Advising_Program_Input.txt");
    vector < Course > courses;
    string line;
    while (!file.eof()) { 
        getline(file, line);
        if (line == "")
            break;
        Course course;
        vector < string > dataT = tokenize(line, ",");
        course.courseNum = dataT[0];
        course.name = dataT[1];
        for (int i = 2; i < dataT.size(); i++) {
            course.prereq.push_back(dataT[i]);
        }
        courses.push_back(course);
    }
    file.close();  
    cout << " : this files data has been loaded into the program. \n";
    return courses;
}

// print course information
void printCourse(Course course) {  
    string num = course.courseNum;
    string name = course.name;
    vector < string > prereq2 = course.prereq;

    cout << "Course Number: " << num << endl;
    cout << "Course Name: " << name << endl;
    cout << "Prerequisites: ";
    for (int i = 0; i < prereq2.size(); i++) {
        cout << prereq2[i] << " ";
    }
}

// print course prereq. list
void printCourseList(vector < Course > courses) {  
    int n = courses.size();

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - j; j++)

        {
            if (courses[j].courseNum > courses[j + 1].courseNum) {
                swap(courses[j + 1], courses[j]);
            }
        }
    }
    for (int i = 0; i < n; i++) {
        printCourse(courses[i]);
    }
}

// create search method from user input
// loop through course list
void searchCourse(vector < Course > courses) { 

    int n = courses.size();
    string courseNum2;
    int j = 0;

    cout << "Please enter a course number: \n";
    cin >> courseNum2;

    for (int i = 0; i < n; i++) { 
        if (courses[i].courseNum == courseNum2) {
            j = 1;
            printCourse(courses[i]);
            break;
        }
    }

    if (j == 0) {
        cout << "The infomation you provided does not match, please select another option.\n";
    }
}

// input menu; int assigned to options in menu
// assigne cases load file, print file, search file
// return user error if case not met
vector < Course > courses;
int main(int argc, char** argv)
{
    vector<Course> courses; 
    cout << "1.Load Data Structure\n";
    cout << "2.Print Course List\n";
    cout << "3.Print Course\n";
    cout << "9.Exit\n";
    int choice; 

    do
    {
        cout << "\nPlease select an option. \n";
        cin >> choice;
        switch (choice)
        {
        case 1:
            courses = LoadDataStructure(); 
            break;
        case 2:
            printCourseList(courses); 
            break;
        case 3:
            searchCourse(courses);
            break;
        case 4:
            break;
        default:
            cout << choice << " is not a valid option\n";
        }
    } while (choice != 4);

    return 0;

}